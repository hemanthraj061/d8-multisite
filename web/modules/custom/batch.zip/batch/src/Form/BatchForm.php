<?php

namespace Drupal\batch\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Datetime\DrupalDateTime;
use Drupal\Core\Url;
use Drupal\Core\Link;

/**
 * Form with examples on how to use cache.
 */
class BatchForm extends FormBase {

  public $id;

  public function getFormId() {
    return 'batch_maintain_form';
  }



    public function buildForm(array $form, FormStateInterface $form_state, $formmode = '', $id = '') 
  {

  $form['#theme'] = 'batchtheme';

  $form['addcomments'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Your name'),
      '#default_value' => '',
    ];

  $form['productcode'] = [
      '#type'          =>  'textfield',
      '#title'  => $this->t('Product Name'),
      '#default_value' => '',
  ];

  $form['batchdate'] = [
      '#type'          => 'date',
      '#title' => $this->t('Batch Date'),
      '#default_value' => '',
  ];

  $form['packdate'] = [
      '#type'          => 'date',
      '#title' => $this->t('Manufactured Date'),
      '#date_format' => 'd-m-Y',
      '#default_value' => '',
  ];

  $form['netweight'] = [
      '#type' => 'textfield',
      '#title'    => $this->t('Net Weight'),
      '#default_value' => ''
  ];
  $form['packedweight'] = [
      '#type' => 'textfield',
      '#title'    => $this->t('Packed Weight'),
      '#default_value' => '',
  ];

  $form['batchtext'] = [
      '#type'          => 'textarea',
      '#title'         =>$this->t('Batch Text'),
      '#default_value' =>  '',
  ];


  $form['customtemplatepk'] = [
      '#type' => 'select',
      '#title'    => $this->t('Template Name'),
      '#options' => $options,
      '#default_value' => array(0=>''),
  ];
drupal_set_message('ss'.$form_state->getValue('packedweight'));
    if ($form_state->getValue('batchtext') == 'yes') {
      $form['form2'] = $this->fapiExamplePageTwo($form, $form_state);
    }


   $form['actions']['next'] = [
        '#type' => 'submit',
        '#value' => $this->t('Apply'),
        '#submit' => ['::fapiExampleMultistepFormNextSubmit'],
        // '#ajax' => [
        //   'wrapper' => 'ajax-example-wizard-wrapper',
        //   // 'callback' => '::promptCallback',
        // ],
      ];

    $form['submit'] = [
      '#type' => 'submit',
      // The AJAX handler will call our callback, and will replace whatever page
      // element has id box-container.
      '#ajax' => [
        'callback' => '::promptCallback',
        'wrapper' => 'box-container',
      ],
      '#value' => $this->t('Submit'),
    ];
    return $form;

  }

 
  public function validateForm(array &$form, FormStateInterface $form_state) {
    parent::validateForm($form, $form_state);

  }
  public function fapiExampleMultistepFormNextSubmit(array &$form, FormStateInterface $form_state) {
    drupal_set_message('hi');
    $form_state->setRebuild();
  }

  public function fapiExamplePageTwo(array &$form, FormStateInterface $form_state) {

    $form['description'] = [
      '#type' => 'item',
      '#title' => $this->t('A basic multistep form (page 2)'),
    ];

    $form['color'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Favorite color'),
      '#required' => TRUE,
      '#default_value' => $form_state->getValue('color', ''),
    ];
    $form['back'] = [
      '#type' => 'submit',
      '#value' => $this->t('Back'),
      // Custom submission handler for 'Back' button.
      '#submit' => ['::fapiExamplePageTwoBack'],
      // We won't bother validating the required 'color' field, since they
      // have to come back to this page to submit anyway.
      '#limit_validation_errors' => [],
    ];
    $form['submit'] = [
      '#type' => 'submit',
      '#button_type' => 'primary',
      '#value' => $this->t('Submit'),
    ];

    return $form;
  }

    public function submitForm(array &$form, FormStateInterface $form_state) {
      drupal_set_message($form_state->getValues());

  }

  

}
